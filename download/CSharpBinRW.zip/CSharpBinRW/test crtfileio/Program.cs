using System;
using System.Collections.Generic;
using System.Text;

namespace test_crtfileio
{
    class Program
    {
        static void Main()
        {
            using (System.IO.BinaryFile bf = new System.IO.BinaryFile("test.txt", System.IO.FileMode.Open))
            {
                Console.WriteLine(bf.Length);

                byte b;

                unsafe
                {
                    Console.WriteLine("  pos: " + bf.Position + "/" + bf.EOF);
                    bf.Seek(-1, System.IO.SeekOrigin.End);
                    bf.Read(&b, 1);
                    Console.WriteLine(b);

                    Console.WriteLine("  pos: " + bf.Position + "/" + bf.EOF);
                    bf.Seek(0, System.IO.SeekOrigin.Begin);
                    bf.Read(&b, 1);
                    Console.WriteLine(b);

                    Console.WriteLine("  pos: " + bf.Position + "/" + bf.EOF);
                    bf.Seek(-1, System.IO.SeekOrigin.Current);
                    bf.Read(&b, 1);
                    Console.WriteLine(b);

                    //bf.Seek(0, System.IO.SeekOrigin.End);
                    b = (byte)(65 + DateTime.Now.Second % 25);
                    Console.WriteLine(":" + b + "/" + bf.Write(&b, 1));
                }

                Console.ReadLine();
            }
        }
    }
}
