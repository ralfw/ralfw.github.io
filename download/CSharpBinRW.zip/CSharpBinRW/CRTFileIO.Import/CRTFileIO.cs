// (c) 2006 by Ralf Westphal, www.ralfw.de

using System;
using System.Collections.Generic;
using System.Text;

namespace System.IO
{
    public class BinaryFile : IDisposable
    {

        #region CRT stdio.h f...() functions
        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private static extern int FileOpen(string filename, string mode);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private static extern void FileClose(int hStream);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private unsafe static extern bool FileReadBuffer(int hStream, void* buffer, short bufferLen);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private unsafe static extern bool FileWriteBuffer(int hStream, void* buffer, short bufferLen);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private unsafe static extern bool FileSeek(int hStream, int offset, short origin);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private unsafe static extern bool FileGetPos(int hStream, out int pos);

        [System.Runtime.InteropServices.DllImport("CRTFileIO.dll")]
        private unsafe static extern bool FileFlush(int hStream);
        #endregion


        string filename;
        int hFile;
        bool currentlyReading;


        public BinaryFile(string filename, System.IO.FileMode mode)
        {
            this.filename = filename;
            
            string crtMode="r+";
            switch (mode)
            {
                case FileMode.Append:
                    crtMode = "a+c";
                    break;
                case FileMode.Create:
                    crtMode = "wc";
                    break;
                case FileMode.CreateNew:
                    if (File.Exists(filename)) throw new IOException("Cannot create new file! File already exists: " + filename);
                    crtMode = "wc";
                    break;
                case FileMode.Open:
                    if (!File.Exists(filename)) throw new FileNotFoundException("Cannot open file! File does not exist: " + filename);
                    crtMode = "r+c";
                    break;
                case FileMode.OpenOrCreate:
                    crtMode = "w+c";
                    break;
                case FileMode.Truncate:
                    crtMode = "w+c";
                    break;
            }

            hFile = FileOpen(filename, crtMode);

            currentlyReading = true;
        }


        public unsafe bool Read(void* buffer, short bufferLen)
        {
            if (!currentlyReading)
            {
                Flush();  // flushing is necessary for "r+", "w+", and "a+" when switching between read/write
                currentlyReading = true;
            }

            return FileReadBuffer(hFile, buffer, bufferLen);
        }


        public unsafe bool ReadStruct<StructType>(void* buffer) where StructType : struct
        {
            return Read(buffer, (short)System.Runtime.InteropServices.Marshal.SizeOf(typeof(StructType)));
        }


        public unsafe bool WriteStruct<StructType>(void* buffer) where StructType : struct
        {
            return Write(buffer, (short)System.Runtime.InteropServices.Marshal.SizeOf(typeof(StructType)));
        }

        public unsafe bool Write(void* buffer, short bufferLen)
        {
            if (currentlyReading)
            {
                Flush(); // flushing is necessary for "r+", "w+", and "a+" when switching between read/write
                currentlyReading = false;
            }

            return FileWriteBuffer(hFile, buffer, bufferLen);
        }


        public bool Seek(int offset, System.IO.SeekOrigin origin)
        {
            //stdio.h:
            //#define SEEK_CUR    1
            //#define SEEK_END    2
            //#define SEEK_SET    0

            short crtOrigin = 0;
            switch (origin)
            {
                case SeekOrigin.Begin:
                    crtOrigin = 0;
                    break;
                case SeekOrigin.Current:
                    crtOrigin = 1;
                    break;
                case SeekOrigin.End:
                    crtOrigin = 2;
                    break;
            }

            return FileSeek(hFile, offset, crtOrigin);
        }


        public long Length
        {
            get
            {
                return new FileInfo(filename).Length;
            }
        }


        public int Position
        {
            get
            {
                int pos;
                if (FileGetPos(hFile, out pos))
                    return pos;
                else
                    return -1;
            }

            set
            {
                if (!Seek(value, SeekOrigin.Begin)) throw new IOException("Cannot position at index: " + value);
            }
        }


        public bool EOF
        {
            get
            {
                return this.Position >= Length;
            }
        }


        public void Flush()
        {
            int pos = this.Position;
            FileFlush(hFile);
            this.Position = pos;
        }


        public void Close()
        {
            lock (this)
            {
                if (hFile != 0)
                {
                    FileClose(hFile);
                    hFile = 0;
                }
            }
        }


        #region IDisposable Members

        public void Dispose()
        {
            this.Close();
        }

        #endregion
    }
}
