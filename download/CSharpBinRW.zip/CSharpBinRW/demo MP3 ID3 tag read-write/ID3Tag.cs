using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace demo_MP3_ID3_tag_read_write
{
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public unsafe struct ID3v1Tag
    {
        private fixed sbyte tag[3];
        private fixed sbyte title[30];
        private fixed sbyte artist[30];
        private fixed sbyte album[30];
        private fixed sbyte year[4];
        private fixed sbyte comment[30];
        private byte genre;

        public string Tag
        {
            get
            {
                fixed (sbyte* pTag = tag)
                {
                    return new string(pTag, 0, 3);
                }
            }
        }

        public string Title
        {
            get
            {
                fixed (sbyte* pTitle = title)
                {
                    return new string(pTitle, 0, 30);
                }
            }

            set
            {
                fixed (sbyte* pTitle = title)
                {
                    CopyStringToField(value, pTitle, 30);
                }
            }
        }

        public string Artist
        {
            get
            {
                fixed (sbyte* pArtist = artist)
                {
                    return new string(pArtist, 0, 30);
                }
            }
            set
            {
                fixed (sbyte* pArtist = artist)
                {
                    CopyStringToField(value, pArtist, 30);
                }
            }
        }

        public string Album
        {
            get
            {
                fixed (sbyte* pAlbum = album)
                {
                    return new string(pAlbum, 0, 30);
                }
            }
            set
            {
                fixed (sbyte* pAlbum = album)
                {
                    CopyStringToField(value, pAlbum, 30);
                }
            }
        }

        public string Year
        {
            get
            {
                fixed (sbyte* pYear = year)
                {
                    return new string(pYear, 0, 4);
                }
            }
            set
            {
                fixed (sbyte* pYear = year)
                {
                    CopyStringToField(value, pYear, 4);
                }
            }
        }

        public string Comment
        {
            get
            {
                fixed (sbyte* pComment = comment)
                {
                    return new string(pComment, 0, this.IsID3v11Tag ? 29 : 30);
                }
            }
            set
            {
                fixed (sbyte* pComment = comment)
                {
                    CopyStringToField(value, pComment, this.IsID3v11Tag ? 29 : 30);
                }
            }
        }


        public sbyte Track
        {
            get
            {
                fixed (sbyte* pComment = comment)
                {
                    if (this.IsID3v11Tag)
                        return *(pComment+29);
                    else
                        return 0;
                }
            }
            set
            {
                fixed (sbyte* pComment = comment)
                {
                    *(pComment + 28) = 0;
                    *(pComment + 29) = value;
                }
            }
        }


        public byte Genre
        {
            get
            {
                return genre;
            }
            set
            {
                genre = value;
            }
        }


        public bool IsID3v11Tag
        {
            get
            {
                fixed (sbyte* pComment = comment)
                {
                    return *(pComment+28) == 0 && *(pComment+29) != 0;
                }
            }
        }

        private void CopyStringToField(string s, sbyte* pBuffer, int bufferSize)
        {
            byte[] charBytes = Encoding.ASCII.GetBytes(s.Substring(0, bufferSize));
            for (int i = 0; i < bufferSize; i++, pBuffer++)
                *pBuffer = i < charBytes.Length ? (sbyte)charBytes[i] : (sbyte)0;
        }
    }
}
