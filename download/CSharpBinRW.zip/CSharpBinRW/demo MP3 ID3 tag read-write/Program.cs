using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace demo_MP3_ID3_tag_read_write
{
    class Program
    {
        static void MainDump(string[] args)
        {
            foreach (string filename in System.IO.Directory.GetFiles(Environment.CurrentDirectory, "*.mp3"))
                DumpMP3Tags(filename);

            Console.WriteLine();
            Console.WriteLine("Hit enter to continue...");
            Console.ReadLine();
        }


        static void Main()
        {
            using (System.IO.BinaryFile fmp3 = new System.IO.BinaryFile("trackwrite.mp3", System.IO.FileMode.Open))
            {
                ID3v1Tag t;

                unsafe
                {
                    fmp3.Seek(-128, System.IO.SeekOrigin.End);
                    //fmp3.Read(&t, (short)Marshal.SizeOf(typeof(ID3v1Tag)));
                    fmp3.ReadStruct<ID3v1Tag>(&t);
                }
                
                if (t.Tag == "TAG")
                {
                    Console.WriteLine("title: " + t.Title);

                    t.Title = t.Title.Substring(0, 10) + "-" + DateTime.Now.ToString();
                    t.Year = DateTime.Now.Year.ToString();

                    unsafe
                    {
                        fmp3.Seek(-128, System.IO.SeekOrigin.End);
                        //fmp3.Write(&t, (short)Marshal.SizeOf(typeof(ID3v1Tag)));
                        fmp3.WriteStruct<ID3v1Tag>(&t);

                        fmp3.Seek(-128, System.IO.SeekOrigin.End);
                        //fmp3.Read(&t, (short)Marshal.SizeOf(typeof(ID3v1Tag)));
                        fmp3.ReadStruct<ID3v1Tag>(&t);

                        Console.WriteLine("  new title: " + t.Title);
                        Console.WriteLine("  new year: " + t.Year);
                    }
                }
            }
        }


        static void DumpMP3Tags(string filename)
        {
            Console.WriteLine();
            Console.WriteLine(System.IO.Path.GetFileName(filename));

            using (System.IO.BinaryFile fmp3 = new System.IO.BinaryFile(filename, System.IO.FileMode.Open))
            {
                fmp3.Seek(-128, System.IO.SeekOrigin.End);

                ID3v1Tag t;
                unsafe
                {
                    fmp3.Read(&t, (short)Marshal.SizeOf(typeof(ID3v1Tag)));
                }

                if (t.Tag == "TAG")
                {
                    Console.WriteLine("ID3v1" + (t.IsID3v11Tag ? ".1" : ""));
                    Console.WriteLine("Title: {0}", t.Title);
                    Console.WriteLine("Artist: {0}", t.Artist);
                    Console.WriteLine("Album: {0}", t.Album);
                    Console.WriteLine("Year: {0}", t.Year);
                    if (t.IsID3v11Tag) Console.WriteLine("Track: {0}", t.Track);
                    Console.WriteLine("Genre: {0}", t.Genre);
                }
            }
        }
    }
}
