// (c) 2006 by Ralf Westphal, www.ralfw.de

#include <stdio.h>


#define DLLEXPORT __declspec(dllexport)


extern "C" DLLEXPORT FILE* __stdcall FileOpen(char *filename, char *mode)
{
	FILE *stream;
	if (fopen_s(&stream, filename, mode) != 0)
		stream = 0;
	return stream;
}

extern "C" DLLEXPORT void __stdcall FileClose(FILE *stream)
{
	if (stream != 0) fclose(stream);
}


extern "C" DLLEXPORT short __stdcall FileReadBuffer(FILE *stream, void *buffer, int bufferLen)
{
	int n = fread(buffer, 1, bufferLen, stream);
	return n == bufferLen;
}


extern "C" DLLEXPORT short __stdcall FileWriteBuffer(FILE *stream, void *buffer, int bufferLen)
{
	int n = fwrite(buffer, 1, bufferLen, stream);
	return n == bufferLen;
}


extern "C" DLLEXPORT short __stdcall FileSeek(FILE *stream, long offset, int origin)
{
	return fseek(stream, offset, origin) == 0;
}


extern "C" DLLEXPORT short __stdcall FileFlush(FILE *stream)
{
	return fflush(stream) == 0;
}



extern "C" DLLEXPORT short __stdcall FileGetPos(FILE *stream, fpos_t *pos)
{
	return fgetpos(stream, pos) == 0;
}

